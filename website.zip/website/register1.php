<?php
    error_reporting(0);
    session_start();
    $connect=mysqli_connect("localhost","root","","mute_speaker");
    if(isset($_REQUEST['btn']))
    {
        $s1=$_REQUEST['a1'];
        $s2=$_REQUEST['a2'];
        $s3=$_REQUEST['a3'];
        $s4=$_REQUEST['a4'];
        $s5=$_REQUEST['a5'];
        
        $insert="insert into users values('','$s2','$s3','$s4','$s5')";
        $result=mysqli_query($connect,$insert);
        if($result)
        {
?>
            
        <script>
            alert("Registered Succesfully.\nNow You can Proceed to Login.");
            window.location.href="login1.php";
        </script>
        
<?php
        }
        else
        {
            echo "Something went wrong";
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <style>
        .container-fluid 
        {
            width:100%;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 737px;
        }
        
        h1
            {
                color: #3714d5;
                text-align: center;    
            }
        input,button
            {
                height: 38px;
            }
        td
            {
                font-size: large;
            }
            p{
                font-size: large;
            }
    </style>
</head>
<body>
<center><h1 style="font-size: 50px;color: White; background-color: #3473ba;height: 60px; margin-top: 0px; padding-top: 5px;" ><i>Mute Speaker</i></h1></center>
    <div>
        <center><img src="img2.avif" alt="" height="280px"></center>
    </div>
    <div>
        <center>
        <form method="post">
        <div>
                <input type="text" style=" width:30%;border-radius:20px; border-color:#3473ba;" placeholder="Enter Name" name="a1" required><br><br>
                <input type="text" style=" width:30%;border-radius:20px; border-color:#3473ba;" placeholder="Enter UserName" name="a2" required><br><br>
                <input type="number" style=" width:30%;border-radius:20px; border-color:#3473ba;" placeholder="Enter Mobile No" name="a3" required><br><br>
                <input type="email" style=" width:30%;border-radius:20px; border-color:#3473ba;" placeholder="Enter Email Id" name="a4" required><br><br>
                <input type="password" style=" width:30%;border-radius:20px; border-color:#3473ba;" placeholder="Enter Password" name="a5" required><br><br>
                <button style="width: 30%;background-color:#3473ba;color: white; font-size: larger; border: none;border-radius:20px;margin-bottom:10px;height:38px;" name="btn">Register</button>
        </form>
        </div>
        </center>
    </div>      
</body>
</html>