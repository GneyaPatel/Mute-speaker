<?php
    error_reporting(0);
    session_start();
    $connect=mysqli_connect("localhost","root","","mute_speaker");

    if(isset($_REQUEST['login']))
    {
        $a1=$_REQUEST['uname'];
        $a2=$_REQUEST['password'];
        $sel="select * from users where Name='$a1' and password='$a2'";
        $res=mysqli_query($connect,$sel);
        $row=mysqli_fetch_array($res);
        $_SESSION['username']=$row['Name'];
        $_SESSION['userid']=$row['UID'];
        if($row)
        {
?>
            
        <script>
            alert("Logged in Succesfully.");
            window.location.href="index1.php";
        </script>
        
<?php
        }
        else
        {
            $msg="Please enter correct UserName & Password";
        }
    }
?>
<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>
            <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
            <style>
                .container-fluid {
                    
                    width:100%;
                    background-size: cover;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 737px;
                    }
                
                h1
                {
                    color: #3714d5;
                    text-align: center;
                    
                }
                input,button{
                    height: 38px;
                }
                td
                {
                    font-size: large;
                }
            
            </style>
        </head>
        <body>
        <center><h1 style="font-size: 50px;color: White; background-color: #3473ba;height: 60px; margin-top: 0px; padding-top: 5px;" ><i>Mute Speaker</i></h1></center>
    <div>
        <center><img src="img2.avif" alt="" height="280px"></center>
    </div>
    <div>
        <center>
        <form method="post">
        <div>
                <input type="text" style=" width:30%;border-radius:20px; border-color:#3473ba;" placeholder="Enter Username" name="uname" required><br><br>
                <input type="password" style=" width:30%;border-radius:20px; border-color:#3473ba;" placeholder="Enter Password" name="password" required><br><br>
                <button style="width: 30%;background-color:#3473ba;color: white; font-size: larger; border: none;border-radius:20px;margin-bottom:10px;height:38px;" name="login">Log In</button><br>
                <button style="width: 30%;background-color:white; border-color: white;color: #6548e3; font-size: large; border-radius:20px;margin-bottom:10px;"><a href="register1.php" style="width: 100%;color: #3473ba; text-decoration: none">Register Yourself</a></button>
                <p style="color: red;"><?php echo $msg;?></p>
        </form>
        </div>
        </center>
    </div>



</body>
</html>