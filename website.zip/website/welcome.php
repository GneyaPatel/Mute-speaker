<?php
    $connect=mysqli_connect("localhost","root","","mute_speaker");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center><h1 style="font-size: 50px;color: White; background-color: #3473ba;height: 60px; margin-top: 0px; padding-top: 5px;" ><i>Mute Speaker</i></h1></center>
    <div>
        <center><img src="img3.jpg" alt="" height="380px"></center>
    </div>
    <center><div style="width:320px;text-align: justify;">
        <h2>What is Mute Speaker?</h2>
        <p style="font-size: large;">We have made the website Mute Speaker for those who cannot speak. By using this website written text will be converted into speech.</p>
    </div></center>
    <center><button style="width: 35%;background-color:#3473ba; border-color: #6548e3;color: white; font-size: large; border-radius:20px;margin-bottom:10px;height: 40px;" name="register"><a href="register1.php" style="text-decoration:none;color: white">New To Website</a></button><br>
    <button style="width: 35%;background-color:#3473ba; border-color: #6548e3;color: white; font-size: large; border-radius:20px;margin-bottom:10px;height: 40px;" name="login"><a href="login1.php" style="text-decoration:none;color: white">Existing User</a></button>
    </center>
</body>
</html>